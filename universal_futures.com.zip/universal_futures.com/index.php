<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "universal_futures";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Tidak Dapat Terkoneksi Ke Database");
}
$nama        = "";
$hp      = "";
$email     = "";
$posisi   = "";
$sukses     = "";
$error      = "";

if (isset($_GET['op'])) {
    $op = $_GET['op'];
} else {
    $op = "";
}
if($op == 'delete'){
    $id         = $_GET['id'];
    $sql1       = "delete from pelamar where id = '$id'";
    $q1         = mysqli_query($koneksi,$sql1);
    if($q1){
        $sukses = "Pelamar Berhasil Di Hapus";
    }else{
        $error  = "Pelamar Gagal Di Hapus";
    }
}
if ($op == 'edit') {
    $id         = $_GET['id'];
    $sql1       = "select * from pelamar where id = '$id'";
    $q1         = mysqli_query($koneksi, $sql1);
    $r1         = mysqli_fetch_array($q1);
    $nama       = $r1['nama'];
    $hp       = $r1['hp'];
    $email     = $r1['email'];
    $posisi   = $r1['posisi'];

    if ($nama == '') {
        $error = "Data tidak ditemukan";
    }
}
if (isset($_POST['simpan'])) { //untuk create
    $nama        = $_POST['nama'];
    $hp       = $_POST['hp'];
    $email     = $_POST['email'];
    $posisi   = $_POST['posisi'];

    if ($nama && $hp && $email && $posisi) {
        if ($op == 'edit') { //untuk update
            $sql1       = "update pelamar set nama = '$nama',hp='$hp',email = '$email',posisi='$posisi' where id = '$id'";
            $q1         = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses = "Data berhasil diupdate";
            } else {
                $error  = "Data gagal diupdate";
            }
        } else { //untuk insert
            $sql1   = "insert into pelamar(nama,hp,email,posisi) values ('$nama','$hp','$email','$posisi')";
            $q1     = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses     = "Data Pelamar Berhasil Di Masukan";
            } else {
                $error      = "Data Pelamar Gagal Di Masukan";
            }
        }
    } else {
        $error = "Silakan Isi Semua Bagian Form Pelamar";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelamar PT. Universal Futures</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        .mx-auto {
            width: 800px
        }

        .card {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="mx-auto">
        <!-- untuk memasukkan data pelamar -->
        <div class="card">
            <div class="card-header">
                Create / Edit Data Pelamar PT. Universal Futures
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error ?>
                    </div>
                <?php
                    header("refresh:1;url=index.php");//
                }
                ?>
                <?php
                if ($sukses) {
                ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $sukses ?>
                    </div>
                <?php
                    header("refresh:1;url=index.php");
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $nama ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="hp" class="col-sm-2 col-form-label">No. HP</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="hp" name="hp" value="<?php echo $hp ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="email" class="col-sm-2 col-form-label">Alamat Email</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="Email" name="email" value="<?php echo $email ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="posisi" class="col-sm-2 col-form-label">Posisi Yang Dilamar</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="posisi" id="posisi">
                                <option value="">- Pilih Posisi Yang di lamar -</option>
                                <option value="IT" <?php if ($posisi == "IT") echo "selected" ?>>IT</option>
                                <option value="HRD" <?php if ($posisi == "HRD") echo "selected" ?>>HRD</option>
                                <option value="GA" <?php if ($posisi == "GA") echo "selected" ?>>GA</option>
                                <option value="FA" <?php if ($posisi == "FA") echo "selected" ?>>FA</option>
                                <option value="Admin" <?php if ($posisi == "Admin") echo "selected" ?>>Admin</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary" />
                    </div>
                </form>
            </div>
        </div>

        <!-- untuk mengeluarkan data -->
        <div class="card">
            <div class="card-header text-white bg-secondary">
                Data Pelamar
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama</th>
                            <th scope="col">HP</th>
                            <th scope="col">Email</th>
                            <th scope="col">Posisi</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql2   = "select * from pelamar order by id asc";
                        $q2     = mysqli_query($koneksi, $sql2);
                        $urut   = 1;
                        while ($r2 = mysqli_fetch_array($q2)) {
                            $id         = $r2['id'];
                            $nama        = $r2['nama'];
                            $hp       = $r2['hp'];
                            $email     = $r2['email'];
                            $posisi   = $r2['posisi'];

                        ?>
                            <tr>
                                <th scope="row"><?php echo $urut++ ?></th>
                                <td scope="row"><?php echo $nama ?></td>
                                <td scope="row"><?php echo $hp ?></td>
                                <td scope="row"><?php echo $email ?></td>
                                <td scope="row"><?php echo $posisi ?></td>
                                <td scope="row">
                                    <a href="index.php?op=edit&id=<?php echo $id ?>"><button type="button" class="btn btn-warning">Edit</button></a>
                                    <a href="index.php?op=delete&id=<?php echo $id?>" onclick="return confirm('Yakin mau delete data?')"><button type="button" class="btn btn-danger">Delete</button></a>            
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>
</body>

</html>
